#pragma once

#define WIFI_SSID  "YOUR_WIFI_SSID"
#define WIFI_PASS  "YOUR_WIFI_PASS"

#define MQTT_HOST  "192.168.1.10"
#define MQTT_PORT  1883
#define MQTT_USER  ""
#define MQTT_PASS  ""
